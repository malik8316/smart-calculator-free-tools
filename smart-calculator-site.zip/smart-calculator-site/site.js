(function(){
var fine=matchMedia('(hover:hover)').matches&&!matchMedia('(prefers-reduced-motion:reduce)').matches;
document.querySelectorAll('.card,section,.about,.feat').forEach(function(el){
  el.addEventListener('pointermove',function(e){var r=el.getBoundingClientRect();el.style.setProperty('--mx',(e.clientX-r.left)+'px');el.style.setProperty('--my',(e.clientY-r.top)+'px');});
});
if(fine){
  var g=document.createElement('div');g.className='glow';document.body.appendChild(g);
  var tx=innerWidth/2,ty=220,x=tx,y=ty;
  addEventListener('pointermove',function(e){tx=e.clientX;ty=e.clientY;});
  (function loop(){x+=(tx-x)*.12;y+=(ty-y)*.12;g.style.transform='translate('+x+'px,'+y+'px)';requestAnimationFrame(loop);})();
  document.querySelectorAll('.card').forEach(function(c){
    c.addEventListener('pointermove',function(e){var r=c.getBoundingClientRect(),px=(e.clientX-r.left)/r.width-.5,py=(e.clientY-r.top)/r.height-.5;c.style.transform='perspective(800px) rotateX('+(-py*6).toFixed(2)+'deg) rotateY('+(px*6).toFixed(2)+'deg) translateY(-4px)';});
    c.addEventListener('pointerleave',function(){c.style.transform='';});
  });
}
document.querySelectorAll('.out').forEach(function(o){
  if(o.querySelector('#tdisp'))return;
  new MutationObserver(function(){o.classList.remove('pop');void o.offsetWidth;o.classList.add('pop');}).observe(o,{childList:true,characterData:true,subtree:true});
});
})();
